import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createServerClient } from "@supabase/ssr"

const PUBLIC_PATHS = ["/", "/sign-in", "/sign-up"]
const PUBLIC_PREFIXES = ["/_next", "/favicon", "/images", "/assets"]

export async function middleware(req: NextRequest) {
  // Guard Supabase envs to prevent runtime crash when variables are missing
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  if (!supabaseUrl || !supabaseAnon) {
    console.log("[v0] Missing Supabase envs in middleware; allowing request to proceed without auth check.")
    return NextResponse.next()
  }

  const url = req.nextUrl
  const isPublic = PUBLIC_PATHS.includes(url.pathname) || PUBLIC_PREFIXES.some((p) => url.pathname.startsWith(p))

  const supabase = createServerClient(supabaseUrl, supabaseAnon, {
    cookies: {
      get(name: string) {
        return req.cookies.get(name)?.value
      },
    },
  })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    // allow public routes, otherwise redirect to sign-in
    if (!isPublic) {
      const redirect = NextResponse.redirect(new URL("/sign-in", req.url))
      return redirect
    }
    return NextResponse.next()
  }

  // If authenticated and hitting "/", redirect to dashboard
  if (url.pathname === "/") {
    return NextResponse.redirect(new URL("/dashboard", req.url))
  }

  // If logged in, ensure profile + Aadhaar verification before accessing non-public app routes (except /aadhaar itself)
  let aadhaarVerified = false
  try {
    const { data: profile } = await supabase
      .from("profiles")
      .select("aadhaar_verified")
      .eq("user_id", user.id)
      .maybeSingle()
    aadhaarVerified = !!profile?.aadhaar_verified
  } catch (_) {}

  // If not verified and trying to access other routes, send to Aadhaar onboarding
  const onAadhaarPage = url.pathname.startsWith("/aadhaar")
  if (!aadhaarVerified && !onAadhaarPage && !isPublic) {
    const redirect = NextResponse.redirect(new URL("/aadhaar", req.url))
    return redirect
  }

  // Authenticated users should not see sign-in/up
  if (isPublic && (url.pathname === "/sign-in" || url.pathname === "/sign-up") && aadhaarVerified) {
    return NextResponse.redirect(new URL("/dashboard", req.url)) // updated redirect URL
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!.*\\.).*)"],
}
