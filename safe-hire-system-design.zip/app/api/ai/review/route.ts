import { NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"
import { generateText } from "ai"

export async function POST(req: Request) {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ ok: false, message: "Unauthorized" }, { status: 401 })

  const { resumeText } = await req.json().catch(() => ({}))
  if (!resumeText || String(resumeText).length < 50) {
    return NextResponse.json({ ok: false, message: "Please paste your resume text (50+ chars)" }, { status: 400 })
  }

  const prompt = `
You are an expert technical recruiter. Review the following resume text and provide:
1) Summary of strengths
2) Key gaps and risks
3) Actionable improvements
4) A score from 0-100 with 1-2 lines of rationale.
Resume:
${resumeText}
`
  try {
    const { text } = await generateText({
      model: "google/gemini-1.5-flash",
      prompt,
    })
    return NextResponse.json({ ok: true, review: text })
  } catch (e: any) {
    return NextResponse.json({ ok: false, message: e?.message || "AI review failed" }, { status: 500 })
  }
}
