"use client"

import type React from "react"

import { useState } from "react"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { Switch } from "@/components/ui/switch"
import { useRouter } from "next/navigation"

export default function SignUpPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isCompany, setIsCompany] = useState(false)
  const [companyName, setCompanyName] = useState("")
  const [companyId, setCompanyId] = useState("") // CIN or PAN
  const router = useRouter()

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    const supabase = getSupabaseBrowser()
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/aadhaar`,
      },
    })
    if (error) {
      setLoading(false)
      setError(error.message)
      return
    }

    // try to ensure session is active right away
    try {
      const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password })
      if (signInErr) {
        console.log("[v0] post-signup sign-in blocked:", signInErr.message)
      }
    } catch (err) {
      console.log("[v0] post-signup sign-in error:", (err as Error).message)
    }

    // If employer, immediately attempt company verification (best-effort)
    if (isCompany && companyName && companyId) {
      try {
        await fetch("/api/profile/mark-employer", { method: "POST" })
      } catch {}
      try {
        const res = await fetch("/api/company/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ registrationNumber: companyId.trim(), name: companyName.trim() }),
        })
        const json = await res.json()
        if (!res.ok || !json?.ok) console.log("[v0] company verification failed:", json)
      } catch (err) {
        console.log("[v0] company verification error:", (err as Error).message)
      }
    }

    setLoading(false)
    router.replace("/aadhaar")
  }

  return (
    <main className="min-h-dvh bg-background flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/15">
          <span className="text-primary text-xl font-semibold">SH</span>
        </div>
        <h1 className="text-3xl font-semibold text-center">Create account</h1>
        <p className="text-center text-muted-foreground mt-2">Sign up and verify with Aadhaar</p>

        <form onSubmit={onSubmit} className="mt-8 rounded-2xl border border-border bg-card/40 p-6 backdrop-blur">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <Label htmlFor="is-company">Signing up as a Company?</Label>
                <p className="text-xs text-muted-foreground">Provide your CIN or PAN to auto-verify your company.</p>
              </div>
              <Switch id="is-company" checked={isCompany} onCheckedChange={setIsCompany} />
            </div>

            {isCompany && (
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="company-name">Company Name</Label>
                  <Input
                    id="company-name"
                    placeholder="Acme Pvt Ltd"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="company-id">CIN or PAN</Label>
                  <Input
                    id="company-id"
                    placeholder="e.g., U12345KA2020PTC012345 or AAAPA1234A"
                    value={companyId}
                    onChange={(e) => setCompanyId(e.target.value.toUpperCase())}
                    required
                  />
                </div>
              </div>
            )}
            {error && <p className="text-sm text-destructive-foreground">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Creating…" : "Sign Up"}
            </Button>
          </div>
          <div className="mt-4 text-center">
            <Link href="/sign-in" className="text-primary text-sm">
              Have an account? Sign in
            </Link>
          </div>
        </form>
      </div>
    </main>
  )
}
