"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

type VerifyResponse = { success: boolean; fullName?: string; message?: string }

export default function AadhaarOnboardingPage() {
  const defaultMode = (process.env.NEXT_PUBLIC_DEFAULT_AADHAAR_MODE || "offline-xml") as "offline-xml" | "demo"
  const [mode, setMode] = useState<"offline-xml" | "demo">(defaultMode)
  const [file, setFile] = useState<File | null>(null)
  const [demoName, setDemoName] = useState("")
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const router = useRouter()

  async function submitOfflineXml(e: React.FormEvent) {
    e.preventDefault()
    if (!file) {
      setMessage("Please choose your Aadhaar XML file.")
      return
    }
    setLoading(true)
    setMessage(null)
    const form = new FormData()
    form.append("file", file)
    const res = await fetch("/api/verify/aadhaar?mode=offline-xml", { method: "POST", body: form })
    const data = (await res.json()) as VerifyResponse
    setLoading(false)
    if (res.status === 401) {
      setMessage("You need to sign in to verify your Aadhaar. Redirecting to Sign In…")
      setTimeout(() => router.replace("/sign-in"), 800)
      return
    }
    if (data.success) {
      setMessage(`Verified as ${data.fullName}`)
      router.replace("/dashboard")
    } else {
      setMessage(data.message || "Verification failed")
    }
  }

  async function submitDemo(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setMessage(null)
    const res = await fetch("/api/verify/aadhaar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "demo", fullName: demoName }),
    })
    const data = (await res.json()) as VerifyResponse
    setLoading(false)
    if (data.success) {
      setMessage(`Verified as ${data.fullName}`)
      router.replace("/dashboard")
    } else {
      setMessage(data.message || "Demo verification failed")
    }
  }

  return (
    <main className="min-h-dvh bg-background flex items-center justify-center px-4">
      <div className="max-w-lg w-full">
        <h1 className="text-3xl font-semibold text-center">Aadhaar Verification</h1>
        <p className="text-center text-muted-foreground mt-2">
          We only extract your full name to match with other documents.
        </p>

        <div className="mt-6 flex gap-2 justify-center">
          <Button
            type="button"
            variant={mode === "offline-xml" ? "default" : "secondary"}
            onClick={() => setMode("offline-xml")}
          >
            Offline XML (UIDAI)
          </Button>
          <Button type="button" variant={mode === "demo" ? "default" : "secondary"} onClick={() => setMode("demo")}>
            Demo
          </Button>
        </div>
        <p className="mt-2 text-center text-xs">
          <a
            href="https://uidai.gov.in/en/307-faqs/aadhaar-online-services/aadhaar-paperless-offline-e-kyc/10731-how-to-generate-offline-aadhaar-2.html"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary underline"
          >
            How to generate Offline eKYC? (UIDAI)
          </a>
        </p>

        {mode === "offline-xml" ? (
          <form
            onSubmit={submitOfflineXml}
            className="mt-8 rounded-2xl border border-border bg-card/40 p-6 backdrop-blur"
          >
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="file">Upload Aadhaar XML</Label>
                <Input
                  id="file"
                  type="file"
                  accept=".xml"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  required
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1" disabled={loading}>
                  {loading ? "Verifying…" : "Verify"}
                </Button>
                <Button type="button" variant="secondary" className="flex-1" onClick={() => router.push("/dashboard")}>
                  Verify later
                </Button>
              </div>
              {message && <p className="text-sm mt-1">{message}</p>}
              <p className="text-xs mt-2 text-muted-foreground">
                Download the password-protected ZIP from the UIDAI portal, extract the XML using your share code on your
                computer, then upload the extracted XML file here. We do not store your Aadhaar number.
              </p>
              <p className="text-xs mt-2">
                <a
                  href="https://myaadhaar.uidai.gov.in/offline-ekyc"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary underline"
                >
                  Generate your Aadhaar Offline eKYC XML on the official UIDAI website
                </a>
              </p>
            </div>
          </form>
        ) : (
          <form onSubmit={submitDemo} className="mt-8 rounded-2xl border border-border bg-card/40 p-6 backdrop-blur">
            <div className="grid gap-2">
              <Label htmlFor="name">Demo Full Name</Label>
              <Input
                id="name"
                placeholder="Priya Sharma"
                value={demoName}
                onChange={(e) => setDemoName(e.target.value)}
                required
              />
              <div className="flex gap-2 mt-4">
                <Button type="submit" className="flex-1" disabled={loading}>
                  {loading ? "Verifying…" : "Verify in Demo"}
                </Button>
                <Button type="button" variant="secondary" className="flex-1" onClick={() => router.push("/dashboard")}>
                  Verify later
                </Button>
              </div>
              {message && <p className="text-sm mt-3">{message}</p>}
            </div>
          </form>
        )}
      </div>
    </main>
  )
}
