alter table public.profiles add column if not exists safe_hire_id text unique;
